document.addEventListener("DOMContentLoaded", function () {
    const themeBtn = document.getElementById("themeBtn");
    const bookBtnHeader = document.getElementById("bookBtnHeader");
    const bookBtnHome = document.getElementById("bookBtnHome");
    const body = document.body;
    const nav = document.getElementById("mainNav");
    const homeSection = document.getElementById("home");
    const hexDivider = document.querySelector(".hex-divider");

    let darkMode = false;

    themeBtn.addEventListener("click", function () {
      darkMode = !darkMode;

      // Переключение фона и текста на всём body
      body.classList.toggle("bg-light", !darkMode);
      body.classList.toggle("text-dark", !darkMode);
      body.classList.toggle("bg-dark", darkMode);
      body.classList.toggle("text-light", darkMode);

      // Меняем классы навигации
      nav.classList.toggle("bg-light", !darkMode);
      nav.classList.toggle("navbar-light", !darkMode);
      nav.classList.toggle("bg-dark", darkMode);
      nav.classList.toggle("navbar-dark", darkMode);

      // смена цвета контейнера home
      if (darkMode) {
    homeSection.style.backgroundColor = "#2b2b2b";
  } else {
    homeSection.style.backgroundColor = "#f0f0f0";
  }

  /* скрытие разделителя в темной теме */

  if (darkMode) {
      hexDivider.style.display = 'none';
    } else {
      hexDivider.style.display = '';
    }

      // Меняем стили кнопок
      themeBtn.textContent = darkMode ? "Changer en clair" : "Changer de theme";
    themeBtn.classList.toggle("btn-outline-light", darkMode);
    themeBtn.classList.toggle("btn-outline-secondary", !darkMode);

    [bookBtnHeader, bookBtnHome].forEach((btn) => {
      if (btn) {
        btn.classList.toggle("btn-outline-light", darkMode);
        btn.classList.toggle("btn-outline-secondary", !darkMode);
      }
    });
  });

  // Модальное окно
  const modalEl = document.getElementById("customModal");
  if (modalEl) {
    const modal = new bootstrap.Modal(modalEl);

    [bookBtnHeader, bookBtnHome].forEach((btn) => {
      if (btn) {
        btn.addEventListener("click", () => modal.show());
      }
    });
  }
});

/* секция меню*/
document.addEventListener("DOMContentLoaded", function () {
    const menuData = {
      starter: [
        { img: "./assets/img/menu/menu-item-1.png", name: "Bruschetta", ingredients: "Tomate, ail, basilic", price: "$5.99" },
        { img: "./assets/img/menu/menu-item-2.png", name: "Soupe du jour", ingredients: "Légumes frais", price: "$4.99" },
        { img: "./assets/img/menu/menu-item-3.png", name: "Mini quiche", ingredients: "Oeufs, fromage", price: "$6.50" }
      ],
      breakfast: [
        { img: "./assets/img/menu/menu-item-4.png", name: "Croissant", ingredients: "Beurre, farine", price: "$2.99" },
        { img: "./assets/img/menu/menu-item-5.png", name: "Omelette", ingredients: "Oeufs, jambon", price: "$5.99" },
        { img: "./assets/img/menu/menu-item-6.png", name: "Pancakes", ingredients: "Sirop, fruits", price: "$6.99" }
      ],
      lunch: [
        { img: "./assets/img/menu/menu-item-2.png", name: "Burger", ingredients: "Boeuf, cheddar, salade", price: "$9.99" },
        { img: "./assets/img/menu/menu-item-3.png", name: "Wrap Poulet", ingredients: "Poulet, légumes", price: "$8.50" },
        { img: "./assets/img/menu/menu-item-5.png", name: "Salade César", ingredients: "Poulet, parmesan, croûtons", price: "$7.99" }
      ],
      dinner: [
        { img: "./assets/img/menu/menu-item-1.png", name: "Steak frites", ingredients: "Boeuf, pommes frites", price: "$14.99" },
        { img: "./assets/img/menu/menu-item-6.png", name: "Saumon grillé", ingredients: "Citron, légumes", price: "$16.99" },
        { img: "./assets/img/menu/menu-item-4.png", name: "Ratatouille", ingredients: "Aubergines, courgettes", price: "$11.50" }
      ]
    };

    const buttons = document.querySelectorAll(".menu-btn");
    const cardContainer = document.getElementById("menu-cards");

    function renderCards(category) {
      cardContainer.innerHTML = "";
      menuData[category].forEach(item => {
        const col = document.createElement("div");
        col.className = "col-md-4";
        col.innerHTML = `
          <div class="menu-card">
            <img src="${item.img}" alt="${item.name}">
            <h5 class="mt-3">${item.name}</h5>
            <p>${item.ingredients}</p>
            <p class="fw-bold">${item.price}</p>
          </div>
        `;
        cardContainer.appendChild(col);
      });
    }

    buttons.forEach(btn => {
      btn.addEventListener("click", function () {
        document.querySelector(".menu-btn.active").classList.remove("active");
        this.classList.add("active");
        const category = this.dataset.category;
        renderCards(category);
      });
    });

    renderCards("starter"); // по умолчанию
  });



